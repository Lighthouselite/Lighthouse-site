export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/lumen", label: "LUMEN" },
  { href: "/echotoken", label: "EchoToken" },
  { href: "/athena-labs", label: "Athena Labs" },
  { href: "/contact", label: "Contact" }
];
